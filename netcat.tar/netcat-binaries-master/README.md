# netcat-binaries
Statically built netcat binaries for Linux (other OSes can be added later)

The source code is not written by me. Check README file for author. Binaries built from netcat 1.10